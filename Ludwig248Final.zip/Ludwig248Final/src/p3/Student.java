package p3;

public class Student implements StudentInterface {

    @Override
    public void doHomework() {
        System.out.println("I am doing my CS homework.");
    }

}
