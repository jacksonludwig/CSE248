package p3;

public interface StudentInterface {
    void doHomework();
}
